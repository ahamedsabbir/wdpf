function sideNavOpen(){
    document.getElementById("sideNav").style.display = "";
}
function sideNavClose(){
    document.getElementById("sideNav").style.display = "none";
}
function searchOpen(){
    document.getElementById("searchBox").style.visibility = "visible";
    document.getElementById("searchBoxButton").style.display = "none";
}
function notificationOpen(){
    alert("lorem text");
}