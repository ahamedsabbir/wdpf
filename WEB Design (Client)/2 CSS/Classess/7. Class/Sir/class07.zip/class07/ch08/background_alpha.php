<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Background with Alpha Transparency</title>
<style>
body {
    margin: 0;
    padding: 0;
    font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif;
    color: #000;
    background-color: #D2E1E6;
}
#yachts {
    width: 500px;
    height: 617px;
    margin: 0 auto;
    background-image: url(images/yachts.jpg);
    background-repeat: no-repeat;
    background-position:center top;
    padding-top: 50px;
}
#sailing {
    background-color: #FFF;
    background: rgba(255, 255, 255, 0.6);
    width: 230px;
    padding: 10px;
    margin-left: 230px;
}
h1 {
    text-align: center;
    margin-top: 0;
}
</style>
</head>

<body>
<div id="yachts">
    <div id="sailing">
        <h1>Sailing</h1>
        <p id="readcontent">One of the great pleasures of the Côte d&rsquo;Azur is  sitting at a beachside café with a nice, cool drink in your hand watching yachts glide across the shimmering surface of the sea. Occasionally, I dream of joining them out there in the fresh breeze and spray. But then I remember my student days, when I tried my hand at sailing. No, let them get cold and wet. I&#8217;ll stay here on dry land with my drink. . .</p>
    </div>
</div>
<script src="asset/jquery-3.7.1.min.js"></script>
<script>
    function talk(s){
        let utterance = new SpeechSynthesisUtterance();

  // Set the text and voice of the utterance
  utterance.text = s;
  utterance.voice = window.speechSynthesis.getVoices()[0];

  // Speak the utterance
  window.speechSynthesis.speak(utterance);
    }
    // talk("hello world!!");
/* alert(5);
        function getVoices() {
            let voices = speechSynthesis.getVoices();
            if (!voices.length) {
                let utterance = new SpeechSynthesisUtterance("");
                speechSynthesis.speak(utterance);
                voices = speechSynthesis.getVoices();
            }
            return voices;
        }
        function talk(s) {
            if ('speechSynthesis' in window) {
                let speakData = new SpeechSynthesisUtterance();
                speakData.volume = 1; // From 0 to 1
                speakData.rate = 1; // From 0.1 to 10
                speakData.pitch = 1; // From 0 to 2
                speakData.text = s;
                speakData.lang = 'en';
                // console.log(getVoices());
                speakData.voice = getVoices()[0];

                speechSynthesis.speak(speakData);
            } else {
                // Speech Synthesis is not Supported 😞 
                // alert(66)
            }
        } */
        $(document).ready(function () {
            let content = $("#readcontent").text();
            // alert(content);
            talk(content);
        });

</script>
</body>
</html>
