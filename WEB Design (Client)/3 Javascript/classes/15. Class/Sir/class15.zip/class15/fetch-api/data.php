<?php
sleep(5);
$countryArr = ["bangladesh","india","cambodia","japan","usa","france","south africa"];
echo json_encode($countryArr);
?>