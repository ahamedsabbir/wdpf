console.log("i can live without HTML now!!");
// int i;
// string name;