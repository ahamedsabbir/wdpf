# HTML5 Canvas Pokemon Game

What more awesome doing a game for fun on HTML5 canvas also when it has to do with the legendary POKEMON !

  - I used HTML5 audio for background and pokeball pickup etc
  - I created a mechanism for walking sprites for the player
  - A technique for the collision on the player objects but also for the pokeball random creation (not to go on the woods or the house)
  - An easy board at the bottom right for displaying to the user his/her score - i have build a mechanism to know which pokeball had picked but is not ready yet

  - You can fork it and start hacking around with it !
  - happy playing !

### DEMO

Try out the [demo] online

[demo]: <http://codepen.io/panvourtsis/pen/Wwdpwm/?editors=0010>

### Version
1.0.0
