alert("Hello World");
alert("Hello World, please");
prompt("Hello World");